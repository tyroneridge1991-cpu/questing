$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
  Write-Host 'Python launcher (py) was not found. Install Python 3.11+ from https://www.python.org/downloads/windows/ and enable Add Python to PATH.'
  exit 1
}

if (-not (Test-Path '.venv')) { py -3 -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt pyinstaller
& .\.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name OSRSQuestNavigator src\app.py
Write-Host ''
Write-Host 'Build complete:'
Write-Host (Join-Path $root 'dist\OSRSQuestNavigator.exe')
