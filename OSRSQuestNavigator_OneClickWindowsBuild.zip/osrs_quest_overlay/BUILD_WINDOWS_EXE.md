# Build the Windows EXE

This project includes a GitHub Actions workflow that builds a single Windows executable on a Windows runner. No Python is needed on your PC to build it.

## If you have GitHub connected
1. Put this folder in a GitHub repository.
2. Push the project.
3. Open **Actions** -> **Build Windows EXE** -> **Run workflow**.
4. When finished, open the workflow run and download the **OSRSQuestNavigator-Windows** artifact.
5. Extract it and double-click `OSRSQuestNavigator.exe`.

The workflow uses PyInstaller's `--onefile --windowed` mode, which packages the Python interpreter and dependencies into one executable.

## Important
The current project is the starter external overlay. It does not yet have full live OSRS map-coordinate tracking or the complete quest database. Those are subsequent development steps.
